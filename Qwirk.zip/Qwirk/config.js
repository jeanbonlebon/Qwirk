// config.js
// This file contains private configuration details.
// Do not add it to your Git repository.
module.exports = {
  "mongodbHost" : "127.0.0.1"
};